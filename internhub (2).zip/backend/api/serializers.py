# backend/api/serializers.py

from rest_framework import serializers
from datetime import date

from .models import (
    Status,
    User,
    ActionLog,
    Department,
    DepartmentUserRole,
    Subject,
    EmployerProfile,
    EmployerInvitation,
    EmployerUserRole,
    PracticeType,
    Practice,
    PracticeUser,
    Role,
    StudentPractice,
    UploadedDocument,
    UserSubject
)

# -------------------------------------------------
# 1. RoleSerializer – musí být nahoře, než se použije
# -------------------------------------------------
class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ['role_id', 'role_name', 'description']
        read_only_fields = ['role_id']


# -----------------------------
# 2. StatusSerializer
# -----------------------------
class StatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = Status
        fields = '__all__'
        read_only_fields = ['status_id']


# -----------------------------
# 3. UserSerializer
# -----------------------------
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'
        read_only_fields = ['user_id']


# -----------------------------
# 4. ActionLogSerializer
# -----------------------------
class ActionLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = ActionLog
        fields = '__all__'
        read_only_fields = ['action_id']


# -----------------------------
# 5. DepartmentSerializer
# -----------------------------
class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = '__all__'
        read_only_fields = ['department_id']


# ------------------------------------------------------------
# 6. DepartmentUserRoleSerializer – používá RoleSerializer
# ------------------------------------------------------------
class DepartmentUserRoleSerializer(serializers.ModelSerializer):
    department = DepartmentSerializer(read_only=True)
    department_id = serializers.PrimaryKeyRelatedField(
        queryset=Department.objects.all(),
        source='department',
        write_only=True,
        required=True
    )

    # Původně na UserSubject, přepíšeme v __init__
    user = serializers.PrimaryKeyRelatedField(
        queryset=UserSubject.objects.none(),
        source='user',
        write_only=True,
        required=True
    )
    user_info = serializers.SerializerMethodField(read_only=True)

    # ROLE – RoleSerializer je již nahoře definovaný
    role = RoleSerializer(read_only=True)
    role_id = serializers.PrimaryKeyRelatedField(
        queryset=Role.objects.all(),
        source='role',
        write_only=True,
        required=True
    )

    class Meta:
        model = DepartmentUserRole
        fields = [
            'id',
            'department',
            'department_id',
            'user',
            'user_info',
            'role',
            'role_id',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Přepsání pole user na skutečný User
        from .models import User
        self.fields['user'] = serializers.PrimaryKeyRelatedField(
            queryset=User.objects.all(),
            write_only=True,
            required=True
        )

    def get_user_info(self, obj):
        if obj.user:
            return {
                'user_id': obj.user.user_id,
                'username': obj.user.username,
            }
        return None


# ------------------------------------------------------------
# 7. SubjectSerializer
# ------------------------------------------------------------
class SubjectSerializer(serializers.ModelSerializer):
    department = DepartmentSerializer(read_only=True)
    department_id = serializers.PrimaryKeyRelatedField(
        queryset=Department.objects.all(),
        source='department',
        write_only=True,
        required=False
    )

    class Meta:
        model = Subject
        fields = [
            'subject_id',
            'subject_code',
            'subject_name',
            'department',
            'department_id',
            'hours_required',
        ]
        read_only_fields = ['subject_id']


# ------------------------------------------------------------
# 8. EmployerProfileSerializer
# ------------------------------------------------------------
class EmployerProfileSerializer(serializers.ModelSerializer):
    approval_status = StatusSerializer(read_only=True)
    approval_status_id = serializers.PrimaryKeyRelatedField(
        queryset=Status.objects.all(),
        source='approval_status',
        write_only=True,
        required=False
    )

    class Meta:
        model = EmployerProfile
        fields = [
            'employer_id',
            'company_name',
            'ico',
            'dic',
            'address',
            'company_profile',
            'approval_status',
            'approval_status_id',
        ]
        read_only_fields = ['employer_id']


# ------------------------------------------------------------
# 9. EmployerInvitationSerializer
# ------------------------------------------------------------
class EmployerInvitationSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployerInvitation
        fields = '__all__'
        read_only_fields = ['invitation_id']


# ------------------------------------------------------------
# 10. EmployerUserRoleSerializer – používá RoleSerializer
# ------------------------------------------------------------
class EmployerUserRoleSerializer(serializers.ModelSerializer):
    employer = EmployerProfileSerializer(read_only=True)
    employer_id = serializers.PrimaryKeyRelatedField(
        queryset=EmployerProfile.objects.all(),
        source='employer',
        write_only=True,
        required=True
    )

    user = serializers.PrimaryKeyRelatedField(
        queryset=UserSubject.objects.none(),
        source='user',
        write_only=True,
        required=True
    )
    user_info = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = EmployerUserRole
        fields = [
            'id',
            'employer',
            'employer_id',
            'user',
            'user_info',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Přepsání pole user na skutečný User
        from .models import User
        self.fields['user'] = serializers.PrimaryKeyRelatedField(
            queryset=User.objects.all(),
            write_only=True,
            required=True
        )

    def get_user_info(self, obj):
        if obj.user:
            return {
                'user_id': obj.user.user_id,
                'username': obj.user.username,
            }
        return None


# ------------------------------------------------------------
# 11. PracticeTypeSerializer
# ------------------------------------------------------------
class PracticeTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PracticeType
        fields = '__all__'
        read_only_fields = ['practice_type_id']


# ------------------------------------------------------------
# 12. PracticeSerializer
# ------------------------------------------------------------
class PracticeSerializer(serializers.ModelSerializer):
    employer = EmployerProfileSerializer(read_only=True)
    employer_id = serializers.PrimaryKeyRelatedField(
        queryset=EmployerProfile.objects.all(),
        source='employer',
        write_only=True,
        required=True
    )

    subject = SubjectSerializer(read_only=True)
    subject_id = serializers.PrimaryKeyRelatedField(
        queryset=Subject.objects.all(),
        source='subject',
        write_only=True,
        required=True
    )

    status = StatusSerializer(read_only=True)
    status_id = serializers.PrimaryKeyRelatedField(
        queryset=Status.objects.all(),
        source='status',
        write_only=True,
        required=False
    )

    approval_status = StatusSerializer(read_only=True)
    approval_status_id = serializers.PrimaryKeyRelatedField(
        queryset=Status.objects.all(),
        source='approval_status',
        write_only=True,
        required=False
    )

    # Pole contact_user bez `source`, protože se jmenuje stejně jako modelové pole
    contact_user = serializers.PrimaryKeyRelatedField(
        queryset=UserSubject.objects.none(),
        write_only=True,
        required=False,
    )
    contact_user_info = serializers.SerializerMethodField(read_only=True)

    practice_type = PracticeTypeSerializer(read_only=True)
    practice_type_id = serializers.PrimaryKeyRelatedField(
        queryset=PracticeType.objects.all(),
        source='practice_type',
        write_only=True,
        required=False
    )

    class Meta:
        model = Practice
        fields = [
            'practice_id',
            'employer',
            'employer_id',
            'subject',
            'subject_id',
            'title',
            'description',
            'responsibilities',
            'available_positions',
            'start_date',
            'end_date',
            'status',
            'status_id',
            'approval_status',
            'approval_status_id',
            'contact_user',
            'contact_user_info',
            'is_active',
            'image_base64',
            'practice_type',
            'practice_type_id',
        ]
        read_only_fields = ['practice_id']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Přepsání pole contact_user na skutečný User
        from .models import User
        self.fields['contact_user'] = serializers.PrimaryKeyRelatedField(
            queryset=User.objects.all(),
            write_only=True,
            required=False
        )

    def get_contact_user_info(self, obj):
        if obj.contact_user:
            return {
                'user_id': obj.contact_user.user_id,
                'username': obj.contact_user.username,
            }
        return None


# ------------------------------------------------------------
# 13. PracticeUserSerializer
# ------------------------------------------------------------
class PracticeUserSerializer(serializers.ModelSerializer):
    practice = PracticeSerializer(read_only=True)
    practice_id = serializers.PrimaryKeyRelatedField(
        queryset=Practice.objects.all(),
        source='practice',
        write_only=True,
        required=True
    )

    user = serializers.PrimaryKeyRelatedField(
        queryset=UserSubject.objects.none(),
        source='user',
        write_only=True,
        required=True
    )
    user_info = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = PracticeUser
        fields = [
            'id',
            'practice',
            'practice_id',
            'user',
            'user_info',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Přepsání pole user na skutečný User
        from .models import User
        self.fields['user'] = serializers.PrimaryKeyRelatedField(
            queryset=User.objects.all(),
            write_only=True,
            required=True
        )

    def get_user_info(self, obj):
        if obj.user:
            return {
                'user_id': obj.user.user_id,
                'username': obj.user.username,
            }
        return None


# ------------------------------------------------------------
# 14. StudentPracticeSerializer
# ------------------------------------------------------------
class StudentPracticeSerializer(serializers.ModelSerializer):
    title = serializers.CharField(source="practice.title", read_only=True)
    logo  = serializers.CharField(source="practice.image_base64", read_only=True)
    status = serializers.CharField(source="approval_status.status_name", read_only=True)

    class Meta:
        model = StudentPractice
        fields = [
            "student_practice_id",
            "practice",
            "title",
            "logo",
            "application_date",
            "approval_status",
            "status"
        ]
        read_only_fields = ["student_practice_id", "title", "logo", "status"]

    def create(self, validated_data):
        if "application_date" not in validated_data:
            validated_data["application_date"] = date.today()
        return super().create(validated_data)


# ------------------------------------------------------------
# 15. UploadedDocumentSerializer
# ------------------------------------------------------------
class UploadedDocumentSerializer(serializers.ModelSerializer):
    practice = PracticeSerializer(read_only=True)
    practice_id = serializers.PrimaryKeyRelatedField(
        queryset=Practice.objects.all(),
        source='practice',
        write_only=True,
        required=True
    )

    class Meta:
        model = UploadedDocument
        fields = [
            'document_id',
            'practice',
            'practice_id',
            'document_name',
            'file_path',
            'uploaded_at',
            'document_type',
        ]
        read_only_fields = ['document_id', 'uploaded_at']


# ------------------------------------------------------------
# 16. UserSubjectSerializer
# ------------------------------------------------------------
class UserSubjectSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(
        queryset=UserSubject.objects.none(),
        source='user',
        write_only=True,
        required=True
    )
    user_info = serializers.SerializerMethodField(read_only=True)

    subject = SubjectSerializer(read_only=True)
    subject_id = serializers.PrimaryKeyRelatedField(
        queryset=Subject.objects.all(),
        source='subject',
        write_only=True,
        required=True
    )

    class Meta:
        model = UserSubject
        fields = [
            'id',
            'user',
            'user_info',
            'subject',
            'subject_id',
            'role',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Přepsání pole user na skutečný User
        from .models import User
        self.fields['user'] = serializers.PrimaryKeyRelatedField(
            queryset=User.objects.all(),
            write_only=True,
            required=True
        )

    def get_user_info(self, obj):
        if obj.user:
            return {
                'user_id': obj.user.user_id,
                'username': obj.user.username,
            }
        return None
