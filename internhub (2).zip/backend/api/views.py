from datetime import date
from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import serializers


from .models import (
    Status, User, ActionLog, Department, DepartmentUserRole, Subject,
    EmployerProfile, EmployerInvitation, EmployerUserRole, PracticeType,
    Practice, PracticeUser, Role, StudentPractice, UploadedDocument, UserSubject
)
from .serializers import (
    StatusSerializer, UserSerializer, ActionLogSerializer, DepartmentSerializer,
    DepartmentUserRoleSerializer, SubjectSerializer, EmployerProfileSerializer,
    EmployerInvitationSerializer, EmployerUserRoleSerializer, PracticeTypeSerializer,
    PracticeSerializer, PracticeUserSerializer, RoleSerializer, StudentPracticeSerializer,
    UploadedDocumentSerializer, UserSubjectSerializer
)

class StatusViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/statuses/
    - GET    → seznam všech statusů (volný přístup)
    - POST   → vytvoření nového statusu (autentizace)
    - GET /{id}/ → detail (volný přístup)
    - PUT/PATCH/DELETE → úprava / smazání (autentizace)
    """
    queryset = Status.objects.all().order_by('status_name')
    serializer_class = StatusSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

class ActionLogViewSet(viewsets.ModelViewSet):
    queryset = ActionLog.objects.all()
    serializer_class = ActionLogSerializer

class DepartmentViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/departments/
    """
    queryset = Department.objects.all().order_by('department_name')
    serializer_class = DepartmentSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]


class DepartmentUserRoleViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/departmentusroles/
    """
    queryset = DepartmentUserRole.objects.all()
    serializer_class = DepartmentUserRoleSerializer

    def get_permissions(self):
        # například jen správci oddělení smí přidávat uživatele do oddělení
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class SubjectViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/subjects/
    """
    queryset = Subject.objects.all().order_by('subject_name')
    serializer_class = SubjectSerializer

    filter_backends = [filters.SearchFilter]
    search_fields = ['subject_name', 'subject_code']

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class EmployerProfileViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/employers/
    """
    queryset = EmployerProfile.objects.all().order_by('company_name')
    serializer_class = EmployerProfileSerializer

    filter_backends = [filters.SearchFilter]
    search_fields = ['company_name', 'ico']

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class EmployerInvitationViewSet(viewsets.ModelViewSet):
    queryset = EmployerInvitation.objects.all()
    serializer_class = EmployerInvitationSerializer

class EmployerUserRoleViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/employerusroles/
    """
    queryset = EmployerUserRole.objects.all()
    serializer_class = EmployerUserRoleSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class PracticeTypeViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/practicetypes/
    """
    queryset = PracticeType.objects.all().order_by('name')
    serializer_class = PracticeTypeSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class PracticeViewSet(viewsets.ModelViewSet):
    """
    /api/practices/
    - GET list                     : veřejný seznam aktivních praxí
    - POST                         : vytvoření praxe zaměstnavatelem
    - GET /{id}/                   : detail
    - POST /{id}/apply/            : student se hlásí na praxi
    """
    queryset = Practice.objects.all().select_related(
        "employer", "practice_type", "status"
    )
    serializer_class = PracticeSerializer

    def get_permissions(self):
        if self.action in ["list", "retrieve"]:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

    def get_queryset(self):
        # pro veřejný výpis vrať jen aktivní praxe
        qs = super().get_queryset()
        if self.action == "list":
            qs = qs.filter(is_active=True)
        return qs

    def perform_create(self, serializer):
        """
        Při vytváření nastavíme:
        - employer přes uživatelův EmployerProfile
        - contact_user = request.user
        - status = 'CREATED'
        """
        user = self.request.user
        employer_profile = getattr(user, "employerprofile", None)
        if employer_profile is None:
            raise serializers.ValidationError("Uživatel nemá EmployerProfile.")
        created_status = Status.objects.get(status_code="CREATED")
        serializer.save(
            employer=employer_profile,
            contact_user=user,
            status=created_status,
            is_active=True,
        )

    # -------  /apply/  -------
    @action(detail=True, methods=["post"], permission_classes=[permissions.IsAuthenticated])
    def apply(self, request, pk=None):
        """
        Student odešle přihlášku na praxi.
        """
        practice = self.get_object()
        already = StudentPractice.objects.filter(
            user=request.user, practice=practice
        ).exists()
        if already:
            return Response(
                {"detail": "Už jste na tuto praxi přihlášen(a)."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        pending_status = Status.objects.get(status_code="APPLICATION_SENT")
        sp = StudentPractice.objects.create(
            user=request.user,
            practice=practice,
            approval_status=pending_status,
            application_date=date.today(),
        )
        return Response(
            StudentPracticeSerializer(sp).data,
            status=status.HTTP_201_CREATED,
        )

class PracticeUserViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/practiceusers/
    """
    queryset = PracticeUser.objects.all()
    serializer_class = PracticeUserSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class RoleViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/roles/
    """
    queryset = Role.objects.all().order_by('role_name')
    serializer_class = RoleSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class SubjectViewSet(viewsets.ModelViewSet):
    """
    /api/subjects/
      - GET   : seznam všech předmětů (volně přístupné)
      - POST  : vytvoření nového předmětu (pouze pro přihlášené s patřičným oprávněním)
      - GET /{id}/ : detail konkrétního předmětu (volně přístupné)
      - PUT/PATCH/DELETE /{id}/ : úprava nebo smazání (pouze pro přihlášené)
    """
    queryset = Subject.objects.all().order_by('subject_name')
    serializer_class = SubjectSerializer

    def get_permissions(self):
        # List a retrieve (pokud action == 'list' nebo 'retrieve') povolit všem; ostatní akce jen pro přihlášené
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class StudentPracticeViewSet(viewsets.ModelViewSet):
    """
    /api/student-practices/
    Student vidí jen své přihlášky.
    """
    serializer_class = StudentPracticeSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return StudentPractice.objects.filter(user=self.request.user).select_related(
            "practice", "approval_status"
        )


class UploadedDocumentViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/documents/
    """
    queryset = UploadedDocument.objects.all().order_by('-uploaded_at')
    serializer_class = UploadedDocumentSerializer

    filter_backends = [filters.SearchFilter]
    search_fields = ['document_name', 'document_type']

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

class UserSubjectViewSet(viewsets.ModelViewSet):
    """
    Endpoint: /api/usersubjects/
    """
    queryset = UserSubject.objects.all()
    serializer_class = UserSubjectSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]
