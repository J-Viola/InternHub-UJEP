from datetime import date
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import serializers


from .models import (
    Status, User, ActionLog, Department, DepartmentUserRole, Subject,
    EmployerProfile, EmployerInvitation, EmployerUserRole, PracticeType,
    Practice, PracticeUser, Role, StudentPractice, UploadedDocument, UserSubject
)
from .serializers import (
    StatusSerializer, UserSerializer, ActionLogSerializer, DepartmentSerializer,
    DepartmentUserRoleSerializer, SubjectSerializer, EmployerProfileSerializer,
    EmployerInvitationSerializer, EmployerUserRoleSerializer, PracticeTypeSerializer,
    PracticeSerializer, PracticeUserSerializer, RoleSerializer, StudentPracticeSerializer,
    UploadedDocumentSerializer, UserSubjectSerializer
)

class StatusViewSet(viewsets.ModelViewSet):
    queryset = Status.objects.all()
    serializer_class = StatusSerializer

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

class ActionLogViewSet(viewsets.ModelViewSet):
    queryset = ActionLog.objects.all()
    serializer_class = ActionLogSerializer

class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer

class DepartmentUserRoleViewSet(viewsets.ModelViewSet):
    queryset = DepartmentUserRole.objects.all()
    serializer_class = DepartmentUserRoleSerializer

class SubjectViewSet(viewsets.ModelViewSet):
    queryset = Subject.objects.all()
    serializer_class = SubjectSerializer

class EmployerProfileViewSet(viewsets.ModelViewSet):
    queryset = EmployerProfile.objects.all()
    serializer_class = EmployerProfileSerializer

class EmployerInvitationViewSet(viewsets.ModelViewSet):
    queryset = EmployerInvitation.objects.all()
    serializer_class = EmployerInvitationSerializer

class EmployerUserRoleViewSet(viewsets.ModelViewSet):
    queryset = EmployerUserRole.objects.all()
    serializer_class = EmployerUserRoleSerializer

class PracticeTypeViewSet(viewsets.ModelViewSet):
    queryset = PracticeType.objects.all()
    serializer_class = PracticeTypeSerializer

class PracticeViewSet(viewsets.ModelViewSet):
    """
    /api/practices/
    - GET list                     : veřejný seznam aktivních praxí
    - POST                         : vytvoření praxe zaměstnavatelem
    - GET /{id}/                   : detail
    - POST /{id}/apply/            : student se hlásí na praxi
    """
    queryset = Practice.objects.all().select_related(
        "employer", "practice_type", "status"
    )
    serializer_class = PracticeSerializer

    def get_permissions(self):
        if self.action in ["list", "retrieve"]:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

    def get_queryset(self):
        # pro veřejný výpis vrať jen aktivní praxe
        qs = super().get_queryset()
        if self.action == "list":
            qs = qs.filter(is_active=True)
        return qs

    def perform_create(self, serializer):
        """
        Při vytváření nastavíme:
        - employer přes uživatelův EmployerProfile
        - contact_user = request.user
        - status = 'CREATED'
        """
        user = self.request.user
        employer_profile = getattr(user, "employerprofile", None)
        if employer_profile is None:
            raise serializers.ValidationError("Uživatel nemá EmployerProfile.")
        created_status = Status.objects.get(status_code="CREATED")
        serializer.save(
            employer=employer_profile,
            contact_user=user,
            status=created_status,
            is_active=True,
        )

    # -------  /apply/  -------
    @action(detail=True, methods=["post"], permission_classes=[permissions.IsAuthenticated])
    def apply(self, request, pk=None):
        """
        Student odešle přihlášku na praxi.
        """
        practice = self.get_object()
        already = StudentPractice.objects.filter(
            user=request.user, practice=practice
        ).exists()
        if already:
            return Response(
                {"detail": "Už jste na tuto praxi přihlášen(a)."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        pending_status = Status.objects.get(status_code="APPLICATION_SENT")
        sp = StudentPractice.objects.create(
            user=request.user,
            practice=practice,
            approval_status=pending_status,
            application_date=date.today(),
        )
        return Response(
            StudentPracticeSerializer(sp).data,
            status=status.HTTP_201_CREATED,
        )

class PracticeUserViewSet(viewsets.ModelViewSet):
    queryset = PracticeUser.objects.all()
    serializer_class = PracticeUserSerializer

class RoleViewSet(viewsets.ModelViewSet):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer

class StudentPracticeViewSet(viewsets.ModelViewSet):
    """
    /api/student-practices/
    Student vidí jen své přihlášky.
    """
    serializer_class = StudentPracticeSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return StudentPractice.objects.filter(user=self.request.user).select_related(
            "practice", "approval_status"
        )


class UploadedDocumentViewSet(viewsets.ModelViewSet):
    queryset = UploadedDocument.objects.all()
    serializer_class = UploadedDocumentSerializer

class UserSubjectViewSet(viewsets.ModelViewSet):
    queryset = UserSubject.objects.all()
    serializer_class = UserSubjectSerializer
